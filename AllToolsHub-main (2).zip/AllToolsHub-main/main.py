from flask import Flask, render_template

app = Flask(__name__)

# 👇 Route for the homepage
@app.route('/')
def home():
    return render_template('tools/video-downloader.html')

# 👇 Route for the About page
@app.route('/about')
def about():
    return render_template('pages/about.html')

# 👇 Route for the Privacy Policy page
@app.route('/privacy-policy')
def privacy():
    return render_template('pages/privacy.html')

# 👇 Route for the Terms page
@app.route('/terms')
def terms():
    return render_template('pages/terms.html')

# 👇 Route for the Contact page
@app.route('/contact')
def contact():
    return render_template('pages/contact.html')

# ✅ VERY IMPORTANT: This makes the app work on Railway
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
